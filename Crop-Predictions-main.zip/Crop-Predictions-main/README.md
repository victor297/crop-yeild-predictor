# Crop-Predictions
 
"Excited to share my latest project on LinkedIn: a crop yield prediction ML model deployed with Streamlit! 🌱 Leveraging the power of Stochastic Gradient Descent regression(SGD) algorithm, this tech-driven solution boasts an impressive 94% accuracy on both training and testing data. Thrilled to contribute to agricultural innovation with cutting-edge technology! Join me in embracing the intersection of technology and agriculture! 🌾💻 #ML #MachineLearning #CropYieldPrediction #Streamlit #SGDAlgorithm #ArtificialIntelligence #AgriTech "

https://crop-predict-pawan.streamlit.app/
